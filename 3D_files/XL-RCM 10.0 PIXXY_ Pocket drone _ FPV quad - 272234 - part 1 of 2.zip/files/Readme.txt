==========================================================
Custom designed 3D printing hobby models/parts
by SupermotoXL Designs. 
==========================================================


Updated 3D models and 3D printed format at:

http://www.supermotoxl.com


****************important note*************************************
Starting 2005 all custom design models and misc item from my work can 
be used freely for both personal and public distribution. You may 
freely edit, use, modify, host on website and made available to the 
public/community for free provided that you must include/attach 
along the description of credits to the original author and links 
of the author's site as shown below. Thank you.
*******************************************************************



Tools for designing these parts.
---------------------------------------------------
Modeler program: 3D Zmodeler 1.07
---------------------------------------------------



E-mail: davidlimars@hotmail.com

Feel free to send me an e-mail if you got any comment or idea to share with me..  Thanks!


  David L.
  SupermotoXL Designs
  ===================
  (http://www.supermotoxl.com)

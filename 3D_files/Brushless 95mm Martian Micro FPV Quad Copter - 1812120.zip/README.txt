Brushless 95mm Martian Micro FPV Quad Copter by CNCNINJA on Thingiverse: https://www.thingiverse.com/thing:1812120

Summary:
This is a brushless version of the 95mm ultra micro Martian FPV racer, this version uses 1103 6~8kv motors 6A Multistar V2 ESC and a Quanum Pico32 FC, 2s 350ma batteries and there is a build video available on youtube. this version is 2g lighter than the brushed version and has more power. 
